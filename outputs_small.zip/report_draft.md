# Training and evaluating a small sparse autoencoder on GPT-2 Small (Group 9)

## 1. Question and setup
[WRITE 2-3 sentences: why 768 coordinates need not be 768 meaningful features, and what you tested.]
I trained sparse autoencoders (SAEs) on the residual stream of frozen GPT-2 Small (evaluation mode, no gradients) at one site:
`blocks.6.hook_resid_post` (Hugging Face `hidden_states[7]`). [STATE which block-6 convention you used.]
The text is WikiText-2 (raw, train split), paragraphs longer than 300 characters, truncated to 64 tokens.
I split the passages into train (208) and held-out (52) sets **before** extracting activations,
which gave 13103 training and 3276 held-out vectors. Token position 0 was excluded: its mean activation norm was
3034.4 against 88.9 at later positions (measured on 16 training passages). Activations were multiplied by one scalar (0.3121),
fit on training data only, so the mean training norm is sqrt(768) = 27.71 (held-out: 27.79). All MSE values below use this scale.

## 2. SAE and training
f = ReLU((h - b_dec) W_enc + b_enc), h_hat = f W_dec + b_dec, with 1024 latents (1,574,656 trainable parameters).
Loss = (1/768)||h - h_hat||^2 + lambda ||f||_1, each averaged over the batch. Decoder rows are renormalized to unit length after every step
(closes the scale loophole). I implemented the SAE and Adam in NumPy and checked the hand-written gradients against finite differences
(max relative error 5.46e-09). Both runs share initialization, batch order, 500 steps, batch size 128, Adam learning rate 0.001.
I chose the two penalties from a short pilot on training data only, using this rule written before looking at held-out results:
[WRITE your rule, for example: high = the largest lambda whose training MSE removed at least 30% of the mean-baseline error; low = ten times smaller].
Result: lambda_low = 0.0003, lambda_high = 0.003.

## 3. Held-out results (3276 vectors; active means latent > 1e-6)
| | lambda = 0.0003 | lambda = 0.003 |
|---|---|---|
| Held-out MSE | 0.0696 | 0.2610 |
| Mean baseline MSE (training mean) | 0.5262 | 0.5262 |
| Variance accounted for | 0.867 | 0.503 |
| Mean active latents (L0) | 543.4 of 1024 | 53.9 of 1024 |
| Never-active latents on this sample | 0.0% | 0.0% |
| Training-set MSE (for comparison) | 0.0525 | 0.2212 |
Figure: `two_runs.png` (training curves, held-out MSE, held-out L0).
Training curve facts: the high-lambda training MSE peaked near step 85 (about 0.36) before declining; final-20-step means were
MSE 0.055 / 0.227 and L0 526 / 49 (low / high lambda).
[WRITE 1-2 sentences: is either run converged? say what you can see in the curves.]

## 4. Inspected features (high-lambda SAE, latents chosen by a rule fixed before reading any contexts)
[For each latent write: top contexts (2-3 short examples), your tentative description, the counterexamples, and whether it held up.]
- Latent 428: tentative description: a length unit right after a number (ft, m, metres, cm, in). Counterexample tests held: 3 of 4. [WRITE what the surprises show.]
- Latent 685: tentative description: the second @ of WikiText's ' @-@ ' hyphen marker (a corpus formatting artifact). Counterexample tests held: 2 of 4. [WRITE what the surprises show.]
- Latent 449: tentative description: a month name in a date expression (March, May, June, ...). Counterexample tests held: 3 of 4. [WRITE what the surprises show.]
Overall 8 of 12 predictions held (a latent 'fires' if its peak is at least 25% of its largest held-out activation).

## 5. Trade-off
[WRITE: did the stronger penalty reduce density? (L0 543 -> 54) What happened to reconstruction? (MSE 0.070 -> 0.261)
Can a model reconstruct well without clean features? Use what the low-lambda contexts showed in Cell 8c.]

## 6. An observation that challenged my expectation
[WRITE one specific, honest observation from YOUR run.]

## 7. Limitations and reproducibility
[WRITE limitations: small data, few steps, one seed, one site, never-active only on this sample, tentative labels.]
Model gpt2 (GPT-2 Small); device cpu; python 3.13.18, numpy 2.1.3, torch 2.11.0+cpu,
transformers 5.20.2, datasets 4.8.5; seeds: data split 0, SAE init 0, batch order 0;
checkpoints and record: `sae_lambda_*.npz`, `results_and_record.json`; passages saved in `passages.json`.

Disclosure: parts of the code were written with help from an AI assistant (Claude). I ran every cell, checked the gradients numerically, and can explain each step.
